<?php
defined( 'ABSPATH' ) or die();
add_filter( 'pre_option_stylesheet', 'DS_theme_hook_style' );
add_filter( 'pre_option_template', 'DS_theme_hook_templ' );
function DS_theme_hook_style() {
	return DS_theme_hook('stylesheet');
}
function DS_theme_hook_templ() {
	return DS_theme_hook('template');
}
function DS_theme_hook($option) {
	global $ds_theme_switcher;
	if (!isset($ds_theme_switcher)) {
		$ds_theme_switcher = array();
	}
	if (isset($ds_theme_switcher[$option])) {
		return $ds_theme_switcher[$option];
	}
	if((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || $_SERVER['SERVER_PORT'] == 443){
		$protocol = "https://";
	} else{
		$protocol = "http://";
	}
	$ID = url_to_postid($protocol.$_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"]);
	if ($ID == 0 && !is_admin()) {
		$ID = get_option('page_on_front');
	}
	if ($ID > 0) {
		global $wpdb;
		$row = $wpdb->get_row('SELECT * FROM '.$wpdb->prefix.'posts WHERE ID = '.$ID, ARRAY_A);
		if (isset($row)) {
			if (strpos($row['post_content'], '[digitalsignage]') > -1) {
				$theme = DS_BLANK_THEME;
			}
		}
	}
	if ( empty ($theme) ) {
		$all_options = wp_load_alloptions();
		$ds_theme_switcher['template'] = $all_options['template'];
		$ds_theme_switcher['stylesheet'] = $all_options['template'];
		return $ds_theme_switcher[$option];
	}
	$themes = wp_get_themes( array( 'allowed' => null ) );
	if ( isset ( $themes[ $theme ] ) ) {
		$ds_theme_switcher['template'] = $themes[ $theme ]->template;
		$ds_theme_switcher['stylesheet'] = $themes[ $theme ]->stylesheet;
		return $ds_theme_switcher[$option];
	} else {
		$theme = str_replace('Plugin', '', $theme);
		if ( isset ( $themes[ $theme ] ) ) {
			$ds_theme_switcher['template'] = $themes[ $theme ]->template;
			$ds_theme_switcher['stylesheet'] = $themes[ $theme ]->stylesheet;
			return $ds_theme_switcher[$option];
		}
	}
	$all_options = wp_load_alloptions();
	$ds_theme_switcher['template'] = $all_options['template'];
	$ds_theme_switcher['stylesheet'] = $all_options['template'];
	return $ds_theme_switcher[$option];
}
