<?php
// base smile xml document
$allowBackground = true; // a screen is also accepted as compatible, if the background is a picture or video
$forceCompleteHtml = true; // forces complete html referencing, if at least one incompatible screen is found
$foundIncompatibleScreenCount = 0; // if this is > 0, we just reference the complete html of the program
// content for the sequence is generated from the screens with landscape fullscreen and/or portrait fullscreen
// otherwise (and if background condition is not met) we use smil to render the complete html for the screen duration
$smilxml='<?xml version="1.0"?>
<!DOCTYPE smil PUBLIC "-//W3C//DTD SMIL 3.0 Language//EN"
                      "http://www.w3.org/2008/SMIL30/SMIL30Language.dtd">
<smil xmlns="http://www.w3.org/ns/SMIL" version="3.0" baseProfile="Language">
 <head>
  <meta name="title" content="fullscreenSequence" />
  <meta http-equiv="Refresh" content="60" />
  <layout>
   <root-layout xml:id="rootLayout" />
     <region xml:id="fullScreen" />
  </layout>
 </head>
 <body>
  <seq repeatCount="indefinite">'.PHP_EOL;
$needlevideo='ds-vid-container-2';
$needleimage='ds-image-container';

$needle2='src="';
$needleend='"';

$now_month = date('Y-m', time());
$now_day = date('Y-m-d', time());

/*
 SchedulingRules:
- Rule 1 : Bei Lücken zwischen 2 Screen: Es wird der erste Screen abgespielt bis der 2. Screen anfängt.
- Rule 2 : 2 Screen und beide Playduration = 0: Es wird der erste der beiden Screens angezeigt
- Rule 3 : 3 Screen und einer hat Playduration = 0: Es wird für den playduration=0 screen die playduration berechnet anhand des Durschschnittswertes der anderen Screen
- Rule 4 : 2 Screens mit playduration>0 überlappen sich: Screen1-End=10, Screen2-Start=9, Dann werden ab Zeit 9 beide Screens im Wechsel angezeigt
 */

$firstscreen = current($program['screens']);

unset($content);

$screens = $program['screens'];

// iterate over all screens to check for general compatibility
foreach($screens as $screen) {
  $htmlcode='';
  // only check fullscreen templates
  if(sizeof($screen['elements']) == 2) { // background and fullscreen layout element
    // first element is background, we need only the first content element (index 1)
    $elements = $screen['elements'];
    foreach($elements as $element) {
      if($element['pos_nr'] == 1) {
         $htmlcode = stripslashes($element['htmlcode']);
         break;
      }
    }
  }
  // does the htmlcode contain content that we can use for SMIL? if not, try to get the background if available
  if($allowBackground && strpos($htmlcode, $needlevideo) === false && strpos($htmlcode, $needleimage) === false) {
	foreach($elements as $element) {
	  if($element['pos_nr'] == 0) { // background
	    $htmlcode = stripslashes($element['htmlcode']);
	    break;
	  }
	}
  }
  if(strpos($htmlcode, $needlevideo) === false && strpos($htmlcode, $needleimage) === false) {
    $foundIncompatibleScreenCount = $foundIncompatibleScreenCount + 1;
  }
}
if($foundIncompatibleScreenCount > 0) {
  error_log('smil, found incompatible screens: '.$foundIncompatibleScreenCount);
}
// special case, if forceCompleteHtml is false but we don't have any compatible screen, force it
if(!$forceCompleteHtml && sizeof($screens) == $foundIncompatibleScreenCount) {
  $forceCompleteHtml = true;
}

foreach($screens as $screen) {
  if(!$forceCompleteHtml || $foundIncompatibleScreenCount == 0) {
    $htmlcode='';
    // first element is background, we need only the first content element (index 1)
    $elements = $screen['elements'];
    foreach($elements as $element) {
      if($element['pos_nr'] == 1) {
         $htmlcode = stripslashes($element['htmlcode']);
         break;
      }
    }
    error_log('smil screen id: '.$screen['id']);
    if(!$forceCompleteHtml && !$allowBackground && empty($htmlcode)) continue;
    // does the htmlcode contain content that we can use for SMIL? if not, try to get the background if available
    if($allowBackground && strpos($htmlcode, $needlevideo) === false && strpos($htmlcode, $needleimage) === false) {
	  foreach($elements as $element) {
	    if($element['pos_nr'] == 0) { // background
	      $htmlcode = stripslashes($element['htmlcode']);
	      break;
	    }
	  }
    }
    error_log('smil screen htmlcode: '.$htmlcode); 
  } else {
    $htmlcode='';
  }

  // SCHEDULING :: START
  $firstschedule=current($screen['schedules']);
  $dur=$firstschedule['playduration']; // playduration should be the same for all schedules within the same screen
  error_log('smil screen dur: '.$dur);

  if($dur == 0) { // Rule 3
    $rule5condition = false;
    $durations = array();
    $tmpscreens = $program['screens'];
    foreach($tmpscreens as $tmpscreen) {
      if($tmpscreen['id'] == $screen['id']) continue;
      $firstschedule=current($tmpscreen['schedules']);
      $tmpdur = $firstschedule['playduration'];
      if($tmpdur > 0) $rule5condition = true;
      $durations[] = $tmpdur;
    }

    $sum = 0;
    foreach($durations as $tmpdur) {
      $sum = $sum + $tmpdur;
    }

    if($rule5condition) {
      $dur_avg = $sum / (sizeof($durations));
    } else {
      unset($dur_avg);
    }
  }

  // Content TODO: for multiple schedulings we are currently having the issue of xml:id multiplication
  if(strpos($htmlcode, $needlevideo) !== false) {
    $firstmatch = strpos($htmlcode, $needlevideo);
    $firstmatch = strpos($htmlcode, $needle2, $firstmatch) + strlen($needle2);
    $endmatch = strpos($htmlcode, $needleend, $firstmatch);
    $videouri = substr($htmlcode, $firstmatch, $endmatch-$firstmatch);
    //TODO currently we are only looking for the first video, but multiple video files could be given for better compatibility
    if($dur > 0) {
      $content ='<video xml:id="v'.$screen['id'].'" region="fullScreen" src="'.$videouri.'" fit="meet" dur="'.$dur.'s" />'.PHP_EOL;
    }/* else if(isset($dur_avg)) { // Rule 3 not really applicable for videos, they should just run until their end
      $content ='<video xml:id="v'.$screen['id'].'" region="fullScreen" src="'.$videouri.'" fit="meet" dur="'.$dur_avg.'s" />'.PHP_EOL;
    }*/ else {
      $content ='<video xml:id="v'.$screen['id'].'" region="fullScreen" src="'.$videouri.'" fit="meet" />'.PHP_EOL;
    }
  } else if(strpos($htmlcode, $needleimage) !== false) {
    $firstmatch = strpos($htmlcode, $needleimage);
    $firstmatch = strpos($htmlcode, $needle2, $firstmatch) + strlen($needle2);
    $endmatch = strpos($htmlcode, $needleend, $firstmatch);
    $imageuri = substr($htmlcode, $firstmatch, $endmatch-$firstmatch);
    if($dur > 0) {
      $content ='<img xml:id="i'.$screen['id'].'" region="fullScreen" src="'.$imageuri.'" fit="meet" dur="'.$dur.'s" />'.PHP_EOL;
    } else if(isset($dur_avg)) { // Rule 3
      $content ='<img xml:id="i'.$screen['id'].'" region="fullScreen" src="'.$imageuri.'" fit="meet" dur="'.$dur_avg.'s" />'.PHP_EOL;
    } else {
      $content ='<img xml:id="i'.$screen['id'].'" region="fullScreen" src="'.$imageuri.'" fit="meet" dur="indefinite" />'.PHP_EOL;
    }
  } else if($forceCompleteHtml) { // found no content, this means that we have a complex screen with no usable background
    $uploads = wp_upload_dir();
    $actualprogramuri = $uploads['basedir'].'/digitalsignagepress/smil/'.$program['id'].'.html';
    $page = $wpdb->get_row('SELECT ID, post_title, guid FROM '.$wpdb->prefix.'posts WHERE post_type = "page" AND post_content LIKE "%[digitalsignage]%" ORDER BY ID LIMIT 1', ARRAY_A);
	$post_url = get_permalink($page['ID']);
	if (empty($post_url)) {
		$post_url = $page['guid'];
	}
	if (strpos($post_url, '?') > -1) {
		$post_url .= '&device=-1';
	} else {
		$post_url .= '?device=-1';
	}
	if (network_home_url('/') != network_site_url('/')) {
		$post_url = str_replace(network_home_url('/'), network_site_url('/'), $post_url );
	}
	// File download mechanism from: https://stackoverflow.com/a/3938844/1257591
    $file = fopen ($post_url.'&type=pip&program='.$program['id'], 'rb');
    if ($file) {
        $newf = fopen ($actualprogramuri, 'wb');
        if ($newf) {
            while(!feof($file)) {
                fwrite($newf, fread($file, 1024 * 8), 1024 * 8);
            }
        }
    }
    if ($file) {
        fclose($file);
    }
    if ($newf) {
        fclose($newf);
    }
    // build the externally reachable path
    $post_url = $uploads['baseurl'].'/digitalsignagepress/smil/'.$program['id'].'.html';
    $content ='<ref xml:id="i'.$program['id'].'" region="fullScreen" src="'.$post_url.'" fit="meet" dur="indefinite" />'.PHP_EOL;
    error_log('smil written html file: '.$actualprogramuri);
    $smilxml .= $content; // add the content before we exit the loop with the next line
    break; // we use the complete website here (as there is no html für just a single screen)
  } else {
    // found no usable content in this screen
    continue;
  }

  if(!$firstschedule['permanent'] && $firstschedule['startdate'] > 0) { // permanent, startdate and enddate should be the same for all schedules within the same screen
    // startdate and enddate are required. SMIL requires ISO 8601 dates. example: <seq begin="wallclock(2010-01-01T09:00)" end="wallclock(2010-01-01T12:00)">
    $smil_startdate = 'begin="wallclock('.date('c', $firstschedule['startdate']).')"';
    $smil_enddate = 'end="wallclock('.date('c', $firstschedule['enddate']).')"';
  } else {
    unset($smil_startdate);
    unset($smil_enddate);
  }

  unset($smil_weekday_start);
  unset($smil_weekday_end);
  unset($smil_day_of_month_start);
  unset($smil_day_of_month_end);

  $schedules=$screen['schedules'];
  foreach($schedules as $schedule) {

    // now check for limitations regarding day of month and/or day of week
    $day_of_month_start = $schedule['day_of_month_start'];
    if($day_of_month_start > 0) {
      if($day_of_month_start < 10) {
        $day_of_month_start = '0'.$day_of_month_start;
      }
      // SMIL example: begin="wallclock(R/2000-01-01T00:00:00/P1M)
      $smil_day_of_month_start = 'begin="wallclock(R/'.$now_month.'-'.$day_of_month_start.'/P1M)"';
      //$smil_day_of_month_start = 'begin="wallclock('.$now_month.'-'.$day_of_month_start.')"';

      $day_of_month_end = $schedule['day_of_month_end'];
      if($day_of_month_end < 10) {
        $day_of_month_end = '0'.$day_of_month_end;
      }
      $smil_day_of_month_end = 'end="wallclock(R/'.$now_month.'-'.$day_of_month_end.'/P1M)"';
      //$smil_day_of_month_end = 'end="wallclock('.$now_month.'-'.$day_of_month_end.')"';
    } else {
      unset($day_of_month_start);
      unset($day_of_month_end);
    }

    // SMIL example: begin="wallclock(R/2000-01-01+w3T09:00/P1W)" end="wallclock(R/2000-01-01+w3T12:00/P1W)
    $weekday_start = $schedule['weekday_start']; // 1 Sunday ... 7 Saturday. SMIL expects 1 for Monday ... 7 for Sunday
    if($weekday_start > 0) {
      if($weekday_start == 1) {
        $weekday_start = 7;
      } else {
        $weekday_start--;
      }
      $weekday_start_time_h = $schedule['weekday_start_time_h'];
      if($weekday_start_time_h < 10) {
        $weekday_start_time_h = '0'.$weekday_start_time_h;
      }
      $weekday_start_time_m = $schedule['weekday_start_time_m'];
      if($weekday_start_time_m < 10) {
        $weekday_start_time_m = '0'.$weekday_start_time_m;
      }
      $smil_weekday_start = 'begin="wallclock(R/'.$now_day.'+w'.$weekday_start.'T'.$weekday_start_time_h.':'.$weekday_start_time_m.'/P1W)"';
      //$smil_weekday_start = 'begin="wallclock('.$now_day.'+w'.$weekday_start.'T'.$weekday_start_time_h.':'.$weekday_start_time_m.')"';
      
      $weekday_end = $schedule['weekday_end'];
      if($weekday_end == 1) {
        $weekday_end = 7;
      } else {
        $weekday_end--;
      }
      $weekday_end_time_h = $schedule['weekday_end_time_h'];
      if($weekday_end_time_h < 10) {
        $weekday_end_time_h = '0'.$weekday_end_time_h;
      }
      $weekday_end_time_m = $schedule['weekday_end_time_m'];
      if($weekday_end_time_m < 10) {
        $weekday_end_time_m = '0'.$weekday_end_time_m;
      }
      $smil_weekday_end = 'end="wallclock(R/'.$now_day.'+w'.$weekday_end.'T'.$weekday_end_time_h.':'.$weekday_end_time_m.'/P1W)"';
      //$smil_weekday_end = 'end="wallclock('.$now_day.'+w'.$weekday_end.'T'.$weekday_end_time_h.':'.$weekday_end_time_m.')"';
    } else {
      unset($weekday_start);
      unset($weekday_end);
    }

    // priority of scheduling is: smil_startdate > smil_day_of_month_start > smil_weekday_start
    if(isset($smil_startdate)) {
      if(isset($smil_day_of_month_start) || isset($smil_weekday_start)) {
        $smilxml .= '<par '.$smil_startdate.' '.$smil_enddate.'>'.PHP_EOL;
      } else {
        // Rule 4: make sure we can alternate between different active screens by limiting the duration accordingly to given values
        if($dur > 0) {
          $smilxml .= '<par '.$smil_startdate.' '.$smil_enddate.' dur="'.$dur.'s" >'.PHP_EOL;
        } else if(isset($dur_avg)) { // Rule 3
          $smilxml .= '<par '.$smil_startdate.' '.$smil_enddate.' dur="'.$dur_avg.'s" >'.PHP_EOL;
        } else {
          $smilxml .= '<par '.$smil_startdate.' '.$smil_enddate.' dur="indefinite" >'.PHP_EOL;
        }
      }
    }

    if(isset($smil_day_of_month_start)) {
      if(isset($smil_weekday_start)) {
        $smilxml .= '<par '.$smil_day_of_month_start.' '.$smil_day_of_month_end.'>'.PHP_EOL;
      } else {
        // Rule 4: make sure we can alternate between different active screens by limiting the duration accordingly to given values
        if($dur > 0) {
          $smilxml .= '<par '.$smil_day_of_month_start.' '.$smil_day_of_month_end.' dur="'.$dur.'s" >'.PHP_EOL;
        } else if(isset($dur_avg)) { // Rule 3
          $smilxml .= '<par '.$smil_day_of_month_start.' '.$smil_day_of_month_end.' dur="'.$dur_avg.'s" >'.PHP_EOL;
        } else {
          $smilxml .= '<par '.$smil_day_of_month_start.' '.$smil_day_of_month_end.' dur="indefinite" >'.PHP_EOL;
        }
      }
    }

    if(isset($smil_weekday_start)) {
      // Rule 4: make sure we can alternate between different active screens by limiting the duration accordingly to given values
      if($dur > 0) {
        $smilxml .= '<par '.$smil_weekday_start.' '.$smil_weekday_end.' dur="'.$dur.'s" >'.PHP_EOL;
      } else if(isset($dur_avg)) { // Rule 3
        $smilxml .= '<par '.$smil_weekday_start.' '.$smil_weekday_end.' dur="'.$dur_avg.'s" >'.PHP_EOL;
      } else {
        $smilxml .= '<par '.$smil_weekday_start.' '.$smil_weekday_end.' dur="indefinite" >'.PHP_EOL;
      }
    }
    // add the content for this schedule (which is always the same for all schedules..)
    $smilxml .= $content;

    // close the tags from nested schedulings
    // special case: no scheduling data was available, this is a screen with indefinite dur!
    if(!isset($smil_startdate) && !isset($smil_weekday_start) && !isset($smil_day_of_month_start)) {
       $smilxml .= '</par>'.PHP_EOL;
    }

    if(isset($smil_startdate)){
      if(isset($smil_day_of_month_start) || isset($smil_weekday_start)) {
        $smilxml .= '</par>'.PHP_EOL;
      } else {
        $smilxml .= '</par>'.PHP_EOL;
      }  
    }

    if(isset($smil_day_of_month_start)) {
      if(isset($smil_weekday_start)) {
        $smilxml .= '</par>'.PHP_EOL;
      } else {
        $smilxml .= '</par>'.PHP_EOL;
      }
    }

    if(isset($smil_weekday_start)) {
      $smilxml .= '</par>'.PHP_EOL;
    }
  }
  // SCHEDULING :: END

  //TODO add prefetching

  // Rule 2 we can skip handling other screens due to the indefinite dur of this screen if Rule 3 is not applyable
  if($dur == 0 && !isset($dur_avg) && strpos($htmlcode, $needlevideo) === false) break; 
}

// write the file if we had any screens with SMIL compatible content
if(isset($content)) {
  $smilxml.='  </seq>
 </body>
</smil>';

  //$path = SIGNAGE_PLUGIN_DIR_PATH.'/smil/';
  $uploads = wp_upload_dir();
  //each site has its own uploads dir, no need to differentiate
  //error_log(function_exists('is_multisite').' AND '.is_multisite().' AND '.$wpdb->blogid);
  //if (function_exists('is_multisite') && is_multisite()) {
  //  $blogid = $wpdb->blogid;
  //  $path = $uploads['basedir'].'/digitalsignagepress/smil_'.$blogid.'/';
  //} else {
    $path = $uploads['basedir'].'/digitalsignagepress/smil/';
  //}
  //error_log('WRITE TO '.$path);
  if (!is_dir($path)) {
    mkdir($path, 0777, true);
  }
  $fp = fopen($path.$program['id'].'.smil', 'w');
  fwrite($fp, $smilxml);
  fclose($fp);
}
//why do we not delete the old file when we don't have a new one?
