<?php
defined( 'ABSPATH' ) or die();
?>
<div class="wrap">
    <h2>My Plugin Options</h2>
    your form and page content goes here
</div>
