var tempWidth = 0;
var tempHeight = 0;
var getSize = function(){
    jQuery('.bgimage').each(function() {
	jQuery(this).parent().width("100%");
	jQuery(this).parent().height("100%");
 	jQuery(this).width("100%");
	jQuery(this).height("100%");

    });
    myresizer();
};
var myresizer = function(){
    jQuery('.ui-resizable .bgimage:visible').each(function() {
		rescaleImg(this);
    });
    pictureResizeFinished = true;
};

function rescaleImg(rootElement) {
	var bg = jQuery(rootElement),
	bgImg = jQuery(rootElement).children("img");
	bgImgWidth = jQuery(bgImg).get(0).naturalWidth;
	bgImgHeight = jQuery(bgImg).get(0).naturalHeight;
	bgWidth = bg.width();
	bgHeight = bg.height();
	bgRatio = (bgWidth / bgHeight);
	imgRatio =  (bgImgWidth / bgImgHeight);
	if (bgRatio > imgRatio) {
		bgImg.addClass('imgWidth');
		bgImg.removeClass('imgHeight');
	} else {
		bgImg.addClass('imgHeight');
		bgImg.removeClass('imgWidth');
	}
};
jQuery(window).load(function(event){
    myresizer();
});
jQuery(window).resize(function(event){
    if (event.target.tagName === "DIV" || event.target.tagName === "div"){
        return;
    }
    myresizer();
});
