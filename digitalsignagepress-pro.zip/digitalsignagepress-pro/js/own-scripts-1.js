jQuery("#btn-debug-9-dev").text("UPDATE");
jQuery("#btn-debug-9-dev").click(function(){
});

